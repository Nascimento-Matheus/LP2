public class Trapezio extends FiguraGeometrica{
	
	private double bMenor, bMaior, altura;

	public void setbMenor(double bMenor){
		this.bMenor=bMenor;
	}

	public void setbMaior(double bMaior){
		this.bMaior=bMaior;
	}
	
	public void setAltura(double altura){
		this.altura=altura;
	}
	
	public double getbMenor(){
		return bMenor;
		}	
		
	public double getbMaior(){
		return bMaior;
		}
	
	public double getAltura(){
		return altura;
		}			
	
	public double calcularAreaTrap(){
		return ((getbMaior()+getbMenor())*getAltura())/2;
		}
		
			
}
