public class Principal{
	public static void main(String[] args){
		System.out.println("Informe a sua forma geométrica :\n");
		System.out.println("1 - Quadrado");
		System.out.println("2 - Triângulo");
		System.out.println("3 - Retângulo");
		System.out.println("4 - Circunferência");
		System.out.println("5 - Trapézio");
		System.out.println("\nOpção : ");
		FiguraGeometrica figura1 = new FiguraGeometrica();
		figura1.setOpcao(3);
		
		if (figura1.getOpcao()==1){
			Quadrado Quadrado1 = new Quadrado();
			Quadrado1.setLado(4.0);
			System.out.println(Quadrado1.calcularPerimetroQua());
			System.out.println(Quadrado1.calcularAreaQua());
			}	
			
		if (figura1.getOpcao()==2){
			Triangulo Triangulo1 = new Triangulo();
			Triangulo1.setL1(4.0);
			Triangulo1.setL2(4.0);
			Triangulo1.setB(4.0);
			Triangulo1.setH(4.0);
			System.out.println(Triangulo1.calcularPerimetroTri());
			System.out.println(Triangulo1.calcularAreaTri());
			}	
			
		if (figura1.getOpcao()==3){
			Retangulo Retangulo1 = new Retangulo();
			Retangulo1.setLado1(4.0);
		    Retangulo1.setLado2(4.0);
			System.out.println(Retangulo1.calcularPerimetroRet());
			System.out.println(Retangulo1.calcularAreaRet());
			}			
			
		if (figura1.getOpcao()==4){
			Circunferencia Circulo1 = new Circunferencia();
			Circulo1.setRaio(4.0);
			System.out.println(Circulo1.calcularPerimetroCir());
			System.out.println(Circulo1.calcularAreaCir());
			}	
			
		if (figura1.getOpcao()==5){
			Trapezio Trapezio1 = new Trapezio();
			Trapezio1.setbMaior(4.0);
			Trapezio1.setbMenor(4.0);
			Trapezio1.setAltura(4.0);
			System.out.println(Trapezio1.calcularAreaTrap());
			}			
		}
	}
