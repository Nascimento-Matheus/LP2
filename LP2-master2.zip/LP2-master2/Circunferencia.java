public class Circunferencia extends FiguraGeometrica{
	
	private double raio;
	private double pi=3.14;
	

	public void setRaio(double raio){
		this.raio=raio;
		}
	
	public double getRaio(){
		return raio;
		}
	
	public double getPi(){
		return pi;
		}		
	
	
	public double calcularPerimetroCir(){
		return (getRaio()*2*getPi());
		}
	
	public double calcularAreaCir(){
		return (getRaio()*getRaio*())*getPi();
		}
		
			
}
