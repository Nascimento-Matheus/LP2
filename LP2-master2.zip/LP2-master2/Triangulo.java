public class Triangulo extends FiguraGeometrica{
	
	private double l1,l2,l3b,h;

	public void setL1(double l1){
		this.l1=l1;
		}
	
	public void setL2(double l2){
		this.l2=l2;
		}
	
	public void setL3b(double l3b){
		this.l3b=l3b;
		}
		
	public void setH(double h){
		this.h=h;
		}
		
	public double getL1(){
		return l1;
		}
	
	public double getL2(){
		return l2;
		}
	
	public double getB(){
		return l3b;
		}
		
	public double getH(){
		return h;
		}
		
	public double calcularPerimetroTri(){
		return (getL1()+getL2()+getB());
		}
	
	public double calcularAreaTri(){
		return (getB()*getH())/2;
		}	
			
		}
	
		
