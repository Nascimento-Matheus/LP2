public class Quadrado extends FiguraGeometrica{
	
	private double lado;

	public void setLado(double lado){
		this.lado=lado;
		}
	
	public double getLado(){
		return lado;
		}	
	
	
	public double calcularPerimetroQua(){
		return getLado()*4;
		}
	
	public double calcularAreaQua(){
		return getLado*getLado;
		}
		
			
}
