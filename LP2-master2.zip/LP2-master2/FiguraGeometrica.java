public class FiguraGeometrica{
	
	int op;
	
	public double calcularPerimetro(int perimetro){
		return perimetro;
		}
	public double calcularArea(int area){
		return area;
		}
	public void setOpcao(int op){
		this.op=op;
		}
	public double getOpcao(){
		return op;
		}		
	}
